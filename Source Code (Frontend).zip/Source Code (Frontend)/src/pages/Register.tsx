import React from 'react';
import RegistrationForm from '../components/RegistrationForm';

const Register: React.FC = () => {
  return <RegistrationForm />;
};

export default Register;